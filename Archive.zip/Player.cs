using System;
using SplashKitSDK;


public class Player
{
    public double X { get; private set; }
    public double Y { get; private set; }
    private bool Quit = false;

    public bool hasQuit()
    {
        return Quit;
    }

    private Window window;
    private Bitmap _PlayerBitmap;
    public int Width
    {
        get
        {
            return _PlayerBitmap.Width;
        }
    }

    public int Height
    {
        get
        {
            return _PlayerBitmap.Height;
        }
    }

    public void HandleInput(double x, double y)
    {
        X = x;
        Y = y;
        int speed = 5;

        if (SplashKit.KeyDown(KeyCode.WKey))
        {
            Y = Y - speed;
        }
        if (SplashKit.KeyDown(KeyCode.SKey))
        {
            Y = Y + speed;
        }
        if (SplashKit.KeyDown(KeyCode.AKey))
        {
            X = X - speed;
        }
        if (SplashKit.KeyDown(KeyCode.DKey))
        {
            X = X + speed;
        }

        const int GAP = 10;
        int wgap = GAP + Width / 2;
        int hgap = GAP + Height / 2;
        if (X <= wgap)
        {
            X = wgap;
        }
        if (X >= window.Width - wgap)
        {
            X = window.Width - wgap;
        }
        if (Y <= hgap)
        {
            Y = hgap;
        }
        if (Y >= window.Height - hgap)
        {
            Y = window.Height - hgap;
        }
    }

    public Player(Window playerwindow, string bmpfilename)
    {
        window = playerwindow;
        _PlayerBitmap = new Bitmap(bmpfilename, bmpfilename);
    }
    public void Draw()
    {
        _PlayerBitmap.Draw(X - Width / 2, Y - Height / 2);
    }

    public void Move()
    {
        if (SplashKit.KeyTyped(KeyCode.EscapeKey))
        {
            Quit = true;
        }
    }
}