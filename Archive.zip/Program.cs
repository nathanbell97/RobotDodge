using System;
using SplashKitSDK;

public class Program
{

    public static void Main()
    {
        Window game = new Window("Robot Dodge", 1200, 800);
        Player plr = new Player(game, "Player.png");
        RobotDodge rbd = new RobotDodge(game, plr);
        while(!plr.hasQuit() || !game.CloseRequested)
        {
            SplashKit.ProcessEvents();
            plr.HandleInput(game.Width / 2, game.Height / 2);
            //plr.Update();
            plr.Draw();
            game.Refresh(60);
        }
        
        
    }
}
